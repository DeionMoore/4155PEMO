export interface Post {
    firstName: String ;
    LastName: String;
    dateOfBirth: String;
    address: String;
    city: String;
    state: String;
    zip: bigint ;
    email: String;
    
    
}